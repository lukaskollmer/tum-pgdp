/*************************************************/
/* In dieser Klasse soll nichts geändert werden. */
/*************************************************/

public class Main {

  public static void main(String[] args) {
    Colony col = new Colony(24,20,true);
  }

}
