
public class Penguin implements Runnable {

  public static final int adultAge = 26;

  // TODO

  public Penguin(boolean female, int x, int y, int age, Colony col) {
    // TODO
  }

  public void run() {
    // TODO
  }

  public int getFg() {
    // TODO
    return GUI.FRAUIN;
  }

}
