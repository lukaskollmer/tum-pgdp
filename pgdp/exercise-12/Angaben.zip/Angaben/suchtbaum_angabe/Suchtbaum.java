public class Suchtbaum<T extends Comparable<T>> {
  private class SuchtbaumElement {
    private T element;
    private SuchtbaumElement left = null;
    private SuchtbaumElement right = null;
    
    /*
     * Todo
     */
  }

  public void insert(T element) throws InterruptedException {
    /*
     * Todo
     */
  }

  public boolean contains(T element) throws InterruptedException {
    /*
     * Todo
     */
  }

  public void remove(T element) throws InterruptedException {
    /*
     * Todo
     */
  }

  @Override
  public String toString() {
    /*
     * Todo
     */
  }
}
