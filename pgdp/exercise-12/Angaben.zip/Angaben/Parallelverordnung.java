
public class Parallelverordnung implements Runnable {
  private int[] numbers;

  public Parallelverordnung (int[] numbers) {
    this.numbers = numbers;
  }

  // Todo

  public static void main (String[] args) {
    int[] numbers = readArray();
    
    // Todo
    
  }

  private static int[] readArray() {
    // Todo
    return null;
  }

  @Override
  public void run() {
    // TODO Auto-generated method stub
    
  }
} // Ende der Klasse Parallelverordnung
