package task_07.ast.statement;

import task_07.compiler.Visitable;

public interface Statement extends Visitable {
}
