package task_07.ast.expression;

import task_07.compiler.Visitable;

public interface Expression extends Visitable {
}
