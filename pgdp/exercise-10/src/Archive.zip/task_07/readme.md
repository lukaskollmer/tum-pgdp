# task_07

## Usage

- `task_07_test.java` contains a bunch of tests
- you can run them simply by running `task_07_test.main` (no need for junit)
- your cwd should be the directory containing `task_07`

(unix)
1. Compile everything (Since we load some classes dynamically, we need to make sure that they are in our `CLASSPATH`)
```bash
find ./task_07 -name "*.java" -print | xargs javac
```

2. Run the tests
```bash
java task_07/task_07_test
```


cleanup:

```bash
find ./task_07 -name "*.class" -type f -delete
```



### brainstorming: optimization

- `jump` instead of `call` to share the stack frame
- that means we need to override the arguments on the stack frame w/ the new arguments
- only if we call the current function
- during optimization, we need to keep track of the currect function
