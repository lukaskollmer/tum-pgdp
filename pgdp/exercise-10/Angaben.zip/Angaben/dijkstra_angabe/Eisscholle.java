package dijkstra_angabe;
public class Eisscholle {

  public final static int UNBEKANNT = 0;
  public final static int VERMUTET = 1;
  public final static int BEKANNT = 2;


  private int distance;
  private Eisscholle vorgaenger;
  private final String name;
  private int state = UNBEKANNT;

  // TODO

  public int getDistance() {
    // TODO
    return 0;
  }
}
