package dijkstra_angabe;
public class Seeweg {
  private int distance;
  private Eisscholle from;
  private Eisscholle to;

  // TODO


  public Eisscholle getFrom() {
    // TODO
    return null;
  }
}
