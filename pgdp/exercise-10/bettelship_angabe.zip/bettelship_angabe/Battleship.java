public class Battleship {
   public static void main(String[] args) {
      Field spielfeld = new Field();
      spielfeld.play();
   }
}
