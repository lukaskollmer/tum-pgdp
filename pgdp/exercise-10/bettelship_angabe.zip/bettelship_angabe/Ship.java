public class Ship {

   // Die vorgegebenen Methoden werden für die Spielfeldausgabe verwendet.

   // TODO Sinnvolle Attribute und Methoden ergänzen


   public boolean contains(Coordinate c) {

      // TODO Zurückgeben, ob c zum Schiff gehört

      return false;
   }

   public boolean isHit(Coordinate c) {

      // TODO Zurückgeben, ob c zum Schiff gehört und bereits richtig geraten wurde

      return false;
   }

   public boolean isSunk() {

      // TODO Wurden bereits alle zum Schiff gehörenden Felder geraten?

      return false;
   }

}
