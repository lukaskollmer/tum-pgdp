import java.io.File;
import nogivan.MapGraph;

/**
 * Diese Klasse erlaubt es, aus einer Datei im OSM-Format ein MapGraph-Objekt zu erzeugen. Sie nutzt
 * dazu einen XML-Parser.
 */
public class MapParser {
  public static MapGraph parseFile(String fileName) {
    File inputFile = new File(fileName);
    /*
     * Todo
     */
  }
}
