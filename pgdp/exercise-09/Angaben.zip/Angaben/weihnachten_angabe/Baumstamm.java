public class Baumstamm extends MultiObject {
  public Baumstamm(int x, int y, int breite) {
    super(x, y, breite);
  }
}
