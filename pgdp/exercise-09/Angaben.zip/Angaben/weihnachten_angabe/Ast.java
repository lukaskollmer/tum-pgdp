public class Ast extends MultiObject{

  public Ast(int x, int y, int breite) {
    super(x, y, breite);
  }
}
