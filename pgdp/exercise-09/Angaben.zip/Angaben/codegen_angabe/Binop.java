public enum Binop {
  Minus, Plus, MultiplicationOperator, DivisionOperator, Modulo
}
