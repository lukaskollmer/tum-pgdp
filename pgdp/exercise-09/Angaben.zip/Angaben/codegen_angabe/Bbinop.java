public enum Bbinop {
  And, Or
}
