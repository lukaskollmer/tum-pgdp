public enum Bunop {
  Not
}
